from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import User

class SignUpForm(UserCreationForm):
    password2 =forms.CharField(label="Confirm Passsword (again)",
    widget = forms.PasswordInput)
    class Meta:
        model = User
        fields =['username','first_name','last_name','email']



    #     name = forms.CharField()
    #     email=forms.EmailField()
    #     password = forms.CharField(widget=forms.PasswordInput)
    # def clean_name(self):
    #     valname = self.cleaned_data['name']
    #     if len(valname) < 4:
    #         raise forms.ValidationError("Enter more than 4 char")
    #     return valname



class HeartDiseaseForm(forms.Form):

    age = forms.FloatField(label='Age', min_value=0, max_value=100, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Enter your Age"}))
    sex = forms.FloatField(label='Sex', min_value=0, max_value=1, widget=forms.NumberInput(attrs={'class': 'form-control',"Placeholder":"Enter 0 for Female & 1 for Male"}))
    cp = forms.FloatField(label='Chest Pain', min_value=0, max_value=100, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Value 1: typical angina, 2: atypical angina, 3: non-anginal pain"}))
    trestbps = forms.FloatField(label='TRESTBPS', min_value=100, max_value=200, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"resting blood pressure mm Hg "}))
    chol = forms.FloatField(label='CHOL', min_value=0, max_value=600, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Enter your Cholesterol Level"}))
    fbs = forms.FloatField(label='FBS', min_value=0, max_value=1, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Fasting blood sugar in mg/dl "}))
    restecg = forms.FloatField(label='RESTECG', min_value=0, max_value=1, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"0:Normal , 1:Abnormal"}))
    thalach = forms.FloatField(label='THALACH', min_value=0, max_value=220, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Maximum heart rate"}))
    exang = forms.FloatField(label='EXANG', min_value=0, max_value=1, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"0 :No , 1: Yes"}))
    oldpeak = forms.FloatField(label='OLDPEAK', min_value=0, max_value=5, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"Oldpeak"}))
    slope = forms.FloatField(label='SLOPE', min_value=0, max_value=3, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":" 0: downsloping, 1:upsloping, 2:flatsploping"}))
    ca = forms.FloatField(label='CA', min_value=0, max_value=100 , widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"0,1,2,3 "}))
    thal = forms.FloatField(label='THAL', min_value=0, max_value=3, widget=forms.NumberInput(attrs={'class': 'form-control',"placeholder":"1:Reversible ,2:Fixed ,3: Normal"}))
