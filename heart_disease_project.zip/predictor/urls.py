from django.urls import path
from . import views

urlpatterns = [
    path('heart/', views.heart, name="heart"),
    path('home/', views.home, name="home"),
    path('',views.sign_up,name='signup'),
    path('login/', views.user_login,name='login'),
    path('logout/', views.user_logout,name='logout'),


]
