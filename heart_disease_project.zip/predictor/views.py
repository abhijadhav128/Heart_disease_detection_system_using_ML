from django.shortcuts import render,HttpResponseRedirect
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from predictor.forms import  HeartDiseaseForm,SignUpForm
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm,UserCreationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages

def sign_up(request):
    if request.method == "POST":
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            messages.success(request,'Account Created Successfully !!')
            fm.save()
    else:
        fm=SignUpForm()
    return render(request, "signup.html",{'form':fm})    


def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fm= AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass =fm.cleaned_data['password']
                user=authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,"Logged in Succesfully !!")
                    return HttpResponseRedirect("/home/")
        else:        
            fm = AuthenticationForm()
        return render(request ,"userlogin.html",{'form':fm})
    else:
        return HttpResponseRedirect('/home/')

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')

def heart(request):
    """ 
    18:39:18 09 Oct, 2019 by Arjun Adhikari
    Reading the training data set. 
    """
    df = pd.read_csv('static/Heart_train.csv')
    data = df.values
    X = data[:, :-1]
    Y = data[:, -1:]

    """ 
    18:39:18 09 Oct, 2019 by Arjun Adhikari
    Reading data from the user. 
    """

    value = ''

    if request.method == 'POST':

        age = float(request.POST['age'])
        sex = float(request.POST['sex'])
        cp = float(request.POST['cp'])
        trestbps = float(request.POST['trestbps'])
        chol = float(request.POST['chol'])
        fbs = float(request.POST['fbs'])
        restecg = float(request.POST['restecg'])
        thalach = float(request.POST['thalach'])
        exang = float(request.POST['exang'])
        oldpeak = float(request.POST['oldpeak'])
        slope = float(request.POST['slope'])
        ca = float(request.POST['ca'])
        thal = float(request.POST['thal'])

        user_data = np.array(
            (age,
             sex,
             cp,
             trestbps,
             chol,
             fbs,
             restecg,
             thalach,
             exang,
             oldpeak,
             slope,
             ca,
             thal)
        ).reshape(1, 13)

        rf = RandomForestClassifier(
            n_estimators=16,
            criterion='entropy',
            max_depth=9
        )

        rf.fit(np.nan_to_num(X), Y)
        rf.score(np.nan_to_num(X), Y)
        predictions = rf.predict(user_data)

        if int(predictions[0]) == 1:
            value = 'have'
        elif int(predictions[0]) == 0:
            value = "don\'t have"

    return render(request,
                  'heart.html',
                  {
                      'context': value,
                      'title': 'Heart Disease Prediction',
                      'active': 'btn btn-success peach-gradient text-white',
                      'heart': True,
                      'form': HeartDiseaseForm(),
                  })



def home(request):
   if request.user.is_authenticated:

    return render(request,'home.html',{'name':request.user})
   else:
       return HttpResponseRedirect('/login/')


""" 
20:07:20 10 Oct, 2019 by Arjun Adhikari
Handling 404 error pages. 
"""


def handler404(request):
    return render(request, '404.html', status=404)
